package com.example.todo11;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    TextView mtextView;
    private String mColour[] = {"red", "pink", "purple", "deep_purple",
            "indigo", "blue", "light_blue", "cyan", "teal", "green",
            "light_green", "lime", "yellow", "amber", "orange", "deep_orange",
            "brown", "grey", "blue_grey", "black"
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mtextView = (TextView) findViewById(R.id.textView);

        // restore saved instance state (the text color)
        if (savedInstanceState != null) {
            mtextView.setTextColor(savedInstanceState.getInt("color"));
        }
    }
    @Override
    public void onSaveInstanceState(Bundle outState) {

        super.onSaveInstanceState(outState);
        outState.putInt("color",mtextView.getCurrentTextColor());
    }

    public void change(View view) {
        Random random=new Random();
        String colorName = mColour[random.nextInt(20)];
        int colorResourceName = getResources().getIdentifier(colorName,"color",getApplication().getPackageName());
        int colorRes= ContextCompat.getColor(this,colorResourceName);
        mtextView.setTextColor(colorRes);

    }
}